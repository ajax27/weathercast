import React from 'react';

const NotFound = () => (
  <div>
    <h1>Whooops. This page doesn't exist</h1>
  </div>
)

export default NotFound;