import React, { Component } from 'react';

class Movie extends Component {
  render() {
    return (
      <div>
        Movie
      </div>
    )
  }
}

export default Movie;