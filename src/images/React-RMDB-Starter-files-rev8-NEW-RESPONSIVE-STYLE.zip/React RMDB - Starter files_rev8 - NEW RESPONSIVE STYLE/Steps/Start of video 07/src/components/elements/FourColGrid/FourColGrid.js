import React from 'react';
import './FourColGrid.css';

const FourColGrid = (props) => {
  return (
    <div>
      FourColGrid
    </div>
  )
}

export default FourColGrid;