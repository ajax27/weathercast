import React from 'react';
import './HeroImage.css';

const HeroImage = (props) => {
  return (
    <div>
      HeroImage
    </div>
  )
}

export default HeroImage;