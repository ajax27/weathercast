import React from 'react';
import './LoadMoreBtn.css';

const LoadMoreBtn = (props) => {
  return (
    <div>
      Load More
    </div>
  )
}

export default LoadMoreBtn;