import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

ReactDOM.render(<p>START HERE</p>, document.getElementById('root'));